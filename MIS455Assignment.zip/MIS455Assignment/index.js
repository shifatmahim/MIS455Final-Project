const searchBox = document.getElementById('searchBox')
const searchBtn = document.getElementById('searchBtn')
const covid = document.getElementById('covid')
const countryContainer = document.getElementById('country')

const headers = {
    headers: { 'Accept': 'application/json' },
}
let countries = []

const clearNodes = (parent) => {
    while (parent.firstChild) {
        parent.firstChild.remove()
    }
}


const getAllCountries = async () => {
    const response = await fetch('https://api.covid19api.com/countries', headers)
    countries = await response.json()

    console.log(countries)
}

getAllCountries()

const outputCovidData = (data) => {
    const div = document.createElement('div')
    div.classList.add('table-responsive')
    const table = document.createElement('table')
    table.classList.add('table', 'table-info')
    const thead = document.createElement('thead')
    const th = document.createElement('tr')
    th.innerHTML = `<tr><th>confirmed</th><th>deaths</th><th>active</th></tr>`
    thead.appendChild(th)
    const tbody = document.createElement('tbody')
    data.forEach(entry => {
        const tr = document.createElement('tr')
        const confirmed = entry['Confirmed']
        const active = entry['Active']
        const deaths = entry['Deaths']
        tr.innerHTML = `<td>${confirmed}</td><td>${deaths}</td><td>${active}</td>`
        tbody.appendChild(tr)
    })
    table.appendChild(thead)
    table.appendChild(tbody)
    div.appendChild(table)
    covid.appendChild(div)
}

const outputCountryData = (country) => {
    const officialName = country['name']['official']
    const capitalName = country['capital'].join(', ')
    const subregionName = country['subregion']
    const populationName = country['population']
    const areaName = country['area']
    const flagLink = country['flags']['svg']

    const flag = document.createElement('img')
    flag.setAttribute('src', flagLink)
    flag.setAttribute('style', 'width: 320px;')
    countryContainer.appendChild(flag)

    const table = document.createElement('table')

    const official = document.createElement('tr')
    official.innerHTML = `<td>Official</td><td></td><td>${officialName}</td>`
    table.appendChild(official)

    const capital = document.createElement('tr')
    capital.innerHTML = `<td>Capital</td><td></td><td>${capitalName}</td>`
    table.appendChild(capital)

    const subregion = document.createElement('tr')
    subregion.innerHTML = `<td>Subregion</td><td></td><td>${subregionName}</td>`
    table.appendChild(subregion)

    const population = document.createElement('tr')
    population.innerHTML = `<td>Population</td><td></td><td>${populationName}</td>`
    table.appendChild(population)

    const area = document.createElement('tr')
    area.innerHTML = `<td>Area</td><td></td><td>${areaName}</td>`
    table.appendChild(area)

    countryContainer.appendChild(table)
}

const getCountryData = async () => {
    const code = document.getElementById('more').getAttribute('iso2')
    const response = await fetch(`https://restcountries.com/v3.1/alpha/${code}`, headers)
    const data = await response.json()
    const country = data[0]
    console.log(country)
    clearNodes(countryContainer)
    outputCountryData(country)
}

const outputMoreBtn = (code) => {
    const button = document.createElement('button')
    button.innerText = 'more details'
    button.setAttribute('iso2', code)
    button.setAttribute('id', 'more')
    button.classList.add('btn', 'btn-secondary')
    button.addEventListener('click', getCountryData)
    covid.appendChild(button)
}

const getCovidData = async (country) => {
    const response = await fetch(`https://api.covid19api.com/country/${country['Slug']}`, headers)
    const data = await response.json()
    data.reverse()
    console.log(data)
    outputMoreBtn(country['ISO2'])
    outputCovidData(data)
}

const search = () => {
    const value = searchBox.value
    const slug = value.toLowerCase().replaceAll(' ', '-')
    const country = countries.find(country => country['Slug'] === slug)
    console.log(country)
    clearNodes(covid)
    clearNodes(countryContainer)
    getCovidData(country)
}

searchBtn.addEventListener('click', search)